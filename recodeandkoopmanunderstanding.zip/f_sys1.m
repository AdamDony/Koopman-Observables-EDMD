function dx = f_x_2d(x)
dx = [-x(1) + x(2)^2;
      -2*x(2) + x(1) * x(2)];
